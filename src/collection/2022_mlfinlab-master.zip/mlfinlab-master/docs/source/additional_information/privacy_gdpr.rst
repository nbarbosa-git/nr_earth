.. _additional_information-analytics:

=======================
Privacy and GDPR Policy
=======================

.. note::
   Our Privacy and GDPR Policies can be downloaded directly from our website:

   * `Privacy Policy <https://hudsonthames.org/wp-content/uploads/2021/06/PrivacyPolicy.pdf>`_
   * `GDPR Policy <https://hudsonthames.org/wp-content/uploads/2021/06/GDPR-Policy.pdf>`_
