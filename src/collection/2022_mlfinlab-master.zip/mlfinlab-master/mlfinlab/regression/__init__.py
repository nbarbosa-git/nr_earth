"""
Implementation of historically weighted regression method based on relevance.
"""

from mlfinlab.regression.history_weight_regression import HistoryWeightRegression
