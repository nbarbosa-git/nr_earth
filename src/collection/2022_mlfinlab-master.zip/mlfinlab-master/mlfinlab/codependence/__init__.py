"""
Various codependence measures: mutual info, distance correlations, variation of information.
"""

from mlfinlab.codependence.correlation import (angular_distance, absolute_angular_distance, squared_angular_distance,
                                               distance_correlation, kullback_leibler_distance, norm_distance)
from mlfinlab.codependence.information import (get_mutual_info, get_optimal_number_of_bins, variation_of_information_score)
from mlfinlab.codependence.codependence_matrix import (get_dependence_matrix, get_distance_matrix)
from mlfinlab.codependence.gnpr_distance import (spearmans_rho, gpr_distance, gnpr_distance)
from mlfinlab.codependence.optimal_transport import (optimal_transport_dependence)
